#include <iostream>
#include "list.h"
using namespace std;

int main()
{
    List myList;
    infotype dNIM;
    address p;
    createList(myList);

    cout << "Masukkan digit pertama NIM : ";
    cin >> dNIM;
    p = allocate(dNIM);
    insertFirst(myList, p);
    printInfo(myList);

    cout << "Masukkan digit kedua NIM : ";
    cin >> dNIM;
    p = allocate(dNIM);
    insertFirst(myList, p);
    printInfo(myList);

    cout << "Masukkan digit ketiga NIM : ";
    cin >> dNIM;
    p = allocate(dNIM);
    insertFirst(myList, p);
    printInfo(myList);



}
